﻿using AuthCe.Domain;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AuthCe.Test
{
    [TestFixture]
    public class DbMenagmentProviderTest
    {
        [Test]
        public void asdf()
        {

        }

    }
}
