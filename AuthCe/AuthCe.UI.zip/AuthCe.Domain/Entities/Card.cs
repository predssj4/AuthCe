﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AuthCe.Domain
{
    public class Card
    {
        public string CardId { get; set; }
        public string IssuedBy { get; set; }
    }
}
